package com.ramonmorell.prices.mapper;

import org.springframework.stereotype.Component;

import com.ramonmorell.prices.dto.PriceResponse;
import com.ramonmorell.prices.entity.PriceEnt;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.ConfigurableMapper;

/**
 * @author ramon
 *
 */
@Component
public class PriceMapper extends ConfigurableMapper {
	
	/**
	 * Configuration custom mapper to map from PriceEnt to PriceDTO.
	 */
	protected void configure(MapperFactory factory) {
		factory.classMap(PriceEnt.class, PriceResponse.class)
			.field("productId", "productId")
			.field("brandId", "brandId")
			.field("priceList", "priceList")
			.field("price", "price")
			.field("curr", "currency")
			.byDefault()
			.register();
	}

}
