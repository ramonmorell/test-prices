package com.ramonmorell.prices.controller;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ramonmorell.prices.dto.PriceResponse;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * @author ramon
 *
 */
@RestController
public interface PriceCtrl {

	/**
	 * Method to handle the get request to response with PriceDTO of given date,
	 * product and brand.
	 * 
	 * @param dateInput
	 * @param product
	 * @param brand
	 * @return
	 */
	@GetMapping(value = "/api/price/{dateInput}/{product}/{brand}", produces = MediaType.APPLICATION_JSON_VALUE)
	@Operation(summary = "Search price", description = "Search price by given date, product id and brand id")
	@ApiResponse(responseCode = "204", description = "Price not found")
	@Tag(name = "API to deal with prices")
	public ResponseEntity<PriceResponse> getPrice(
			@Parameter(description = "The String of date of application, format in 'yyyy-MM-dd-HH.mm.ss'") String dateInputString,
			@Parameter(description = "The id of the product") Long product,
			@Parameter(description = "The id of the brand") Long brand) throws Exception;

}
