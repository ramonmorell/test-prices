package com.ramonmorell.prices.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.ramonmorell.prices.dto.PriceResponse;
import com.ramonmorell.prices.service.PriceSrv;
import com.ramonmorell.prices.validators.PriceRequestValidator;

/**
 * @author ramon
 *
 */
@RestController
public class PriceCtrlImpl implements PriceCtrl {

	private PriceSrv productsSrv;

	/**
	 * Constructor of PriceCtrlImpl, injection of dependencies by constructor.
	 * 
	 * @param productsSrv
	 */
	public PriceCtrlImpl(PriceSrv productsSrv) {
		this.productsSrv = productsSrv;
	}

	/**
	 * Method to handle the get request to response with PriceDTO of given date,
	 * product and brand.
	 * 
	 * @param dateInput
	 * @param product
	 * @param brand
	 * @return
	 * @throws Exception
	 */
	@Override
	public ResponseEntity<PriceResponse> getPrice(@PathVariable("dateInput") String dateInputString,
			@PathVariable("product") Long product, @PathVariable("brand") Long brand) {

		LocalDateTime dateTime = null;
		if (PriceRequestValidator.validateDateInput(dateInputString)) {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss");
			dateTime = LocalDateTime.parse(dateInputString, formatter);
		}
		PriceRequestValidator.validateProduct(product);
		PriceRequestValidator.validateBrand(brand);

		return Optional.ofNullable(productsSrv.getPrice(dateTime, product, brand))
				.map(priceDTO -> ResponseEntity.ok().body(priceDTO))
				.orElseGet(() -> ResponseEntity.status(HttpStatus.NO_CONTENT).build());
	}

}
