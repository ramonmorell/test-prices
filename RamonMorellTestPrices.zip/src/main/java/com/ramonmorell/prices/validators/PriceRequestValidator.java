package com.ramonmorell.prices.validators;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import com.ramonmorell.prices.exceptions.CustomInvalidException;

/**
 * @author ramon
 *
 */
public class PriceRequestValidator {

	private final static Long ZERO = 0L;

	/**
	 * Method to validate DateInput.
	 * 
	 * @param dateInput
	 * @return
	 */
	public static boolean validateDateInput(String dateInput) {
		if (dateInput != null) {
			try {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss");
				LocalDateTime.parse(dateInput, formatter);
			} catch (DateTimeParseException e) {
				throw new CustomInvalidException("Error formatting Date, format correct is 'yyyy-MM-dd-HH.mm.ss'");
			}
		} else {
			throw new CustomInvalidException("dateInput is required, format correct is 'yyyy-MM-dd-HH.mm.ss'");
		}

		return true;
	}

	/**
	 * Method to validate product.
	 * 
	 * @param product
	 * @return
	 */
	public static boolean validateProduct(Long product) {
		if (product == null || product.equals(ZERO)) {
			throw new CustomInvalidException("product is resquired");
		}

		return true;
	}

	/**
	 * Method to validate brand.
	 * 
	 * @param brand
	 * @return
	 */
	public static boolean validateBrand(Long brand) {
		if (brand == null || brand.equals(ZERO)) {
			throw new CustomInvalidException("brand is resquired");
		}

		return true;
	}

}
