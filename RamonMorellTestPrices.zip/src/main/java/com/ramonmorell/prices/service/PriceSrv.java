package com.ramonmorell.prices.service;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

import com.ramonmorell.prices.dto.PriceResponse;

/**
 * @author ramon
 *
 */
@Service
public interface PriceSrv {

	/**
	 * Method to get a PriceDTO of given date, product and brand.
	 * @param dateInput
	 * @param product
	 * @param brand
	 * @return
	 */
	public PriceResponse getPrice(LocalDateTime dateInput, Long product, Long brand);
}
