package com.ramonmorell.prices.service;

import java.time.LocalDateTime;

import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.stereotype.Service;

import com.ramonmorell.prices.dto.PriceResponse;
import com.ramonmorell.prices.entity.PriceEnt;
import com.ramonmorell.prices.exceptions.CustomInvalidException;
import com.ramonmorell.prices.repository.PriceRepository;

import ma.glasnost.orika.MapperFacade;

/**
 * @author ramon
 *
 */
@Service
public class PriceSrvImpl implements PriceSrv {

	private PriceRepository repository;

	private MapperFacade mapper;

	/**
	 * Constructor of PriceSrvImpl, injection of dependencies by constructor.
	 * 
	 * @param repository
	 * @param mapper
	 */
	public PriceSrvImpl(PriceRepository repository, MapperFacade mapper) {
		super();
		this.repository = repository;
		this.mapper = mapper;
	}

	/**
	 * Method to get a PriceDTO of given date, product and brand.
	 * 
	 * @param dateInput
	 * @param product
	 * @param brand
	 * @return
	 */
	@Override
	public PriceResponse getPrice(LocalDateTime dateInput, Long product, Long brand) {
		PriceResponse res = null;
		try {
			PriceEnt entity = repository.findByDateAndProductIdAndBrandId(dateInput, product, brand);
			if (entity != null) {
				res = mapper.map(entity, PriceResponse.class);
				res.setDateApplication(dateInput);
			}
		} catch (IncorrectResultSizeDataAccessException e) {
			throw new CustomInvalidException("Error quering the DDBB, too many results");
		} catch (Exception e) {
			throw new CustomInvalidException("Generic error quering DDBB");
		}

		return res;
	}

}
