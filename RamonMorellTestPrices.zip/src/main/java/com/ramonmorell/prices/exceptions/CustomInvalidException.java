package com.ramonmorell.prices.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @author ramon
 *
 */
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class CustomInvalidException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor to create custom Exception.
	 * 
	 * @param s
	 */
	public CustomInvalidException(String s) {
		super(s);
		this.setStackTrace(new StackTraceElement[0]);
	}
}
