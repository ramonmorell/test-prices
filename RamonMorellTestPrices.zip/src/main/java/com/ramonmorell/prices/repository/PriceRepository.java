package com.ramonmorell.prices.repository;

import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ramonmorell.prices.entity.PriceEnt;

/**
 * @author ramon
 *
 */
@Repository
public interface PriceRepository extends JpaRepository<PriceEnt, Long> {

	/**
	 * Method to get PriceEnt from DDBB of given date, product and brand.
	 * @param date
	 * @param productId
	 * @param brandId
	 * @return
	 */
	@Query(value = "SELECT p FROM PriceEnt p "
			+ "WHERE (p.startDate <= :dateInput AND "
			+ "p.endDate >= :dateInput) AND "
			+ "p.productId = :productId AND "
			+ "p.brandId = :brandId AND "
			+ "p.priority = (SELECT MAX(p.priority) FROM p "
				+ "WHERE (p.startDate <= :dateInput AND "
				+ "p.endDate >= :dateInput) AND "
				+ "p.productId = :productId AND "
				+ "p.brandId = :brandId)")
	PriceEnt findByDateAndProductIdAndBrandId(@Param("dateInput") LocalDateTime date,
			@Param("productId") Long productId, @Param("brandId") Long brandId);
}
