package com.ramonmorell.prices;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PricesApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
