package com.ramonmorell.prices;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ramonmorell.prices.dto.PriceResponse;

/**
 * @author ramon
 *
 */
@SpringBootTest
@AutoConfigureMockMvc
class PricesControllerTests {

	@Autowired
	private MockMvc mvc;

	@Autowired
	private ObjectMapper objectMapper;

	@Test
	public void getPricesTest1() throws Exception {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss");
		PriceResponse mockedPrice = new PriceResponse(35455L, 1L, new BigDecimal("1"),
				LocalDateTime.parse("2020-06-14-10.00.00", formatter), new BigDecimal("35.5"), "EUR");

		final String expectedResponseContent = objectMapper.writeValueAsString(mockedPrice);

		this.mvc.perform(get("/api/price/2020-06-14-10.00.00/35455/1")).andExpect(status().isOk())
				.andExpect(content().json(expectedResponseContent));

	}

	@Test
	public void getPricesTest2() throws Exception {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss");
		PriceResponse mockedPrice = new PriceResponse(35455L, 1L, new BigDecimal("2"),
				LocalDateTime.parse("2020-06-14-16.00.00", formatter), new BigDecimal("25.45"), "EUR");

		final String expectedResponseContent = objectMapper.writeValueAsString(mockedPrice);

		this.mvc.perform(get("/api/price/2020-06-14-16.00.00/35455/1")).andExpect(status().isOk())
				.andExpect(content().json(expectedResponseContent));

	}

	@Test
	public void getPricesTest3() throws Exception {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss");
		PriceResponse mockedPrice = new PriceResponse(35455L, 1L, new BigDecimal("1"),
				LocalDateTime.parse("2020-06-14-21.00.00", formatter), new BigDecimal("35.5"), "EUR");

		final String expectedResponseContent = objectMapper.writeValueAsString(mockedPrice);

		this.mvc.perform(get("/api/price/2020-06-14-21.00.00/35455/1")).andExpect(status().isOk())
				.andExpect(content().json(expectedResponseContent));

	}

	@Test
	public void getPricesTest4() throws Exception {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss");
		PriceResponse mockedPrice = new PriceResponse(35455L, 1L, new BigDecimal("3"),
				LocalDateTime.parse("2020-06-15-10.00.00", formatter), new BigDecimal("30.5"), "EUR");

		final String expectedResponseContent = objectMapper.writeValueAsString(mockedPrice);

		this.mvc.perform(get("/api/price/2020-06-15-10.00.00/35455/1")).andExpect(status().isOk())
				.andExpect(content().json(expectedResponseContent));

	}

	@Test
	public void getPricesTest5() throws Exception {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss");
		PriceResponse mockedPrice = new PriceResponse(35455L, 1L, new BigDecimal("4"),
				LocalDateTime.parse("2020-06-16-21.00.00", formatter), new BigDecimal("38.95"), "EUR");

		final String expectedResponseContent = objectMapper.writeValueAsString(mockedPrice);

		this.mvc.perform(get("/api/price/2020-06-16-21.00.00/35455/1")).andExpect(status().isOk())
				.andExpect(content().json(expectedResponseContent));

	}

}
